package com.wancarvalho;

public class Conta {
    private static int AGENCIA_PADRAO = 1;

    private int agencia;
    private double saldo;

    public Conta(){
        this.agencia = AGENCIA_PADRAO;
        this.saldo = 0;
    }

    public int getAgencia(){
        return this.agencia;
    }

    public double getSaldo(){
        return this.saldo;
    }

    public void setSaldo(double valor){
        this.saldo += valor;

        System.out.println("Depósito de R$" + valor + " realizado com sucesso.");
    }

    public String saque(double valor){
        if(valor > this.saldo){
            return "Não possui saldo para saque.";
        } else {
            this.saldo -= valor;

            return "Saque de R$"+valor+" realizado com sucesso.";
        }
    }
}
