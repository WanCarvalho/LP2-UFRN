package com.wancarvalho;

public class Main {
    public static void main(String[] args) {

        Conta conta1 = new Conta();

        System.out.println("Sua conta foi criada e o seu saldo é de: R$"+conta1.getSaldo());

        Pessoa pessoa1 = new Pessoa("Wanderson", 22, conta1);

        //realizada depósito de R$100,00
        pessoa1.depositar(100);

        //verifica saldo
        System.out.println(pessoa1.verificarSaldo());

        //tenta sacar valor maior que o saldo em conta
        System.out.println(pessoa1.sacar(150));

        //tenta sacar valor disponível no saldo em conta
        System.out.println(pessoa1.sacar(75));

        //verifica saldo
        System.out.println(pessoa1.verificarSaldo());
    }
}