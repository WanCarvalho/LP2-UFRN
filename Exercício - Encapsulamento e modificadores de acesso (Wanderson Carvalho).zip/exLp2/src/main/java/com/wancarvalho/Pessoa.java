package com.wancarvalho;

public class Pessoa {
    private String nome;
    private int idade;
    protected Conta contaBancaria;

    public Pessoa(String nome, int idade, Conta contaBancaria){
        this.nome = nome;
        this.idade = idade;
        this.contaBancaria = contaBancaria;
    }

    public String getNome(){
        return this.nome;
    }

    public int getIdade(){
        return this.idade;
    }

    public void setNome(String nome){
        this.nome = nome;
    }

    public void setIdade(int idade){
        this.idade = idade;
    }

    public int verificarAgencia(){
        return contaBancaria.getAgencia();
    }

    public String verificarSaldo(){
        return "Seu saldo é de: R$"+contaBancaria.getSaldo();
    }

    public void depositar(double valor){
        contaBancaria.setSaldo(valor);
    }

    public String sacar(double valor){
        return contaBancaria.saque(valor);
    }

}
